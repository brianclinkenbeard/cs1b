#ifndef _H_
#define _H_

/*
 * Brian Clinkenbeard | 1059593 | CS1B TTh 2:30 PM
 * Assignment 4
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

int menu();
void add(double[3][3], double[3][3], double[3][3]);
void sub(double[3][3], double[3][3], double[3][3]);
void mul(double[3][3], double[3][3], double[3][3]);
void det(double[3][3], double[3][3], double[3][3]);

#endif
