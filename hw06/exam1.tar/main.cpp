#include "header.h"

int main()
{
	cout << "Brian Clinkenbeard | 1059593 | CS1B TTh 2:30PM | Exam 1" << endl;
	double darray[50];
	/* initialize and print array */
	initArray(darray);
	prArray(darray);

	return 0;
}
