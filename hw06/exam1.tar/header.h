#ifndef _H_
#define _H_

/*
 * Brian Clinkenbeard | 1059593 | CS1B TTh 2:30 PM
 * Exam 1
 */

#include <iostream>
using namespace std;

void initArray(double[]);
void prArray(double[]);

#endif
