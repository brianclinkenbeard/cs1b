#pragma once

/*
 * Brian Clinkenbeard | CS1B TTh 2:30 PM
 * Lab 2
 */

#include <iostream>
using namespace std;

class datePiece {
  public:
    void setDate(int, int, int);
    void getDate(int &, int &, int &) const;
    void incrDay();
    void incrMonth();
    void incrYear();
    void incrWeek();
    void prDate();
    bool compDate(const datePiece &) const;
  private:
    int day;
    int month;
    int year;
    int dow;
    int week;
    char monthName[];
    char dowName[];
};
          