#include "header.h"

void datePiece::incrYear()
{
  year++;
}
