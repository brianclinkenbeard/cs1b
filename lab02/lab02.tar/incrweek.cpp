#include "header.h"

void datePiece::incrWeek()
{
  week++;
  if (week > 52) {
    week -= 52;
    year++;
  }
}
