#include "header.h"

int main()
{
  datePiece date;
  date.setDate(1, 1, 1);
  date.prDate();
  date.incrDay();
  date.incrMonth();
  date.incrYear();
  date.prDate();
  return 0;
}
