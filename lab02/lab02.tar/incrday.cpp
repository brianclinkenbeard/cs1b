#include "header.h"

void datePiece::incrDay()
{
  day++;
  if (day > 31) {
    day -= 31;
    incrMonth();
  }
}
