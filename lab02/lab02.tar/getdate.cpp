#include "header.h"

void datePiece::getDate(int& newDay, int& newMonth, int& newYear) const
{
  newDay = day;
  newMonth = month;
  newYear = year;
}
