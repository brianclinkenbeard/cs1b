#include "header.h"

void datePiece::prDate()
{
  cout << month << "/" << day << "/" << year << endl;
}
