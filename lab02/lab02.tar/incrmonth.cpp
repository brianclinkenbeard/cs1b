#include "header.h"

void datePiece::incrMonth()
{
  month++;
  if (month > 12) {
    month -= 12;
    incrYear();
  }
}
