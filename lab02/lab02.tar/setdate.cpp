#include "header.h"

void datePiece::setDate(int newDay, int newMonth, int newYear)
{
  day = newDay;
  month = newMonth;
  year = newYear;
}
