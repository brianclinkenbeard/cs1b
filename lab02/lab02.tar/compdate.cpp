#include "header.h"

bool datePiece::compDate(const datePiece& date) const
{
  return (day == date.day && month == date.month && year == date.year);
}
