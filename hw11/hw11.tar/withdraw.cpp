#include "header.h"

void bankAccount::withdraw(double amount)
{
  balance -= amount;
}
