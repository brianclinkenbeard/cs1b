#include "header.h"

void bankAccount::deposit(double amount)
{
  balance += amount;
}
