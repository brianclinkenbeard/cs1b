#include "header.h"

string bankAccount::getName()
{
  return name;
}
