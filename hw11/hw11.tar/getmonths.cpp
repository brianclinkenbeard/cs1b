#include "header.h"

int bankAccount::getMonths()
{
  return months;
}
