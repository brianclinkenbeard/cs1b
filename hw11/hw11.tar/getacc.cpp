#include "header.h"

int bankAccount::getAccount()
{
  return number;
}
