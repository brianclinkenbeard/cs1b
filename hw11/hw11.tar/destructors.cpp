#include "header.h"

bankAccount::~bankAccount() {}
checkingAccount::~checkingAccount() {}
noServiceChargeChecking::~noServiceChargeChecking() {}
savingsAccount::~savingsAccount() {}
