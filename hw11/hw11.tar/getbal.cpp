#include "header.h"

double bankAccount::getBalance()
{
  return balance;
}
