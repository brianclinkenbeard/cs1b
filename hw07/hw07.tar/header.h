#pragma once

/*
 * Brian Clinkenbeard | 1059593 | CS1B TTh 2:30 PM
 * Assignment 7
 */

#include <iostream>
using namespace std;
