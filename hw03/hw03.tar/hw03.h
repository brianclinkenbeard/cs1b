#ifndef _H_
#define _H_

/*
 * Brian Clinkenbeard | 1059593 | CS1B TTh 2:30 PM
 * Assignment 3
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#endif
