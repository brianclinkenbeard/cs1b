#include <string>
using namespace std;

void rotate(string word, char array[])
{
  char last = array[word.length() - 1];
  for (int i = word.length() - 1; i > 0; i--) {
    array[i] = array[i - 1];
  }
  array[0] = last;
}
