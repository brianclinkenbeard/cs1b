#ifndef _H_
#define _H_

/*
 * Brian Clinkenbeard | 1059593 | TTh 2:30 PM
 * Lab 04
 */

#include <iostream>
#include <string>
using namespace std;

void rotate(string, char[]);
void userinput(string, char[]);

#endif
