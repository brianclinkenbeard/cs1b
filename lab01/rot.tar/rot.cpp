#include "header.h"

int main()
{
  /* get a word from the user */
  string word;
  cout << "Enter a word:" << endl;
  cin >> word;
  cout << endl;

  /* create array from word */
  char array[word.length() - 1];
  userinput(word, array);

  /* output rotations */
  cout << "Press Enter to rotate:";
  cin.ignore();
  for (int i = 0; i < word.length(); i++) {
    rotate(word, array);
    cin.ignore();
    cout << array;
  }
  cout << endl;

  return 0;
}
