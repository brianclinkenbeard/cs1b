#ifndef _H_
#define _H_

/*
 * Brian Clinkenbeard | 1059593 | CS1B TTh 2:30-5:50 PM
 * Assignment 2
 */

#include <iostream>
using namespace std;

#endif
