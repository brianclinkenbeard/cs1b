#include "header.h"

int matrix::getColumns()
{
  return columns;
}
