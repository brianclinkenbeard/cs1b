#include "header.h"

int matrix::getRows()
{
  return rows;
}
